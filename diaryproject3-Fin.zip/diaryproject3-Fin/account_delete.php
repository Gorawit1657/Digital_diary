<?php
// Start the session
session_start();

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to delete user from the 'log_in' table
    $sql = "DELETE FROM log_in WHERE user_id = $user_id";

    if ($conn->query($sql) === TRUE) {

        // Perform logout (optional)
        session_unset();
        session_destroy();

        // Redirect to a different page (optional)
        header('Location: welcome.php');
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    // If the user is not logged in, you might want to redirect them to the login page
    header('Location: login.php');
    exit();
}
?>
