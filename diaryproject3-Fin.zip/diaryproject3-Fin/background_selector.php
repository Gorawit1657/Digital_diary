<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>setting page 5</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400"/>
  <link rel="stylesheet" href="./styles/setting-page-5.css"/>
</head>
<body>
<div class="setting-page-5-qHB">
  <div class="rectangle-7-B69">
  </div>
  <div class="rectangle-8-uXw">
  </div>
  <div class="group-3-Fbo">
    <p class="now-lets-customize-the-in-side-of-your-journal-k2m">Now Let’s customize the in side of your journal.</p>
    <p class="journal-background-p2d">JOURNAL BACKGROUND</p>
    <div class="auto-group-gacy-ido">
      
        <button style="background: transparent; border: none; padding: 0; cursor: pointer;" onclick="redirectToBackgroundUpdate(1)">
          <img class="auto-group-1gg1-E6M" src="./assets/auto-group-1gg1.png"/>
        </button>
      
        <button style="background: transparent; border: none; padding: 0; cursor: pointer;" onclick="redirectToBackgroundUpdate(2)">
        <div class="auto-group-pexr-x2M">
            <img class="ellipse-51-iGR" src="./assets/ellipse-51.png"/>
        </div>
        </button>

        <button style="background: transparent; border: none; padding: 0; cursor: pointer;" onclick="redirectToBackgroundUpdate(3)">
        <div class="auto-group-xcem-eA5">
         
            <img class="ellipse-53-c6u"  src="./assets/ellipse-53.png"/>
        </div>
        </button>
    </div>
  </div>

  <script>
    function redirectToBackgroundUpdate(id) {
      window.location.href = 'background_update_process.php?id=' + id;
    }
  </script>
</div>
</body>
</html>
