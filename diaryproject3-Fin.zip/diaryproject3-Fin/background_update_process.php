<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
    session_start();
    // Retrieve data from the query parameters
    $background_id = (int) $_GET["id"];
    $user_id = $_SESSION['user_id'];
    $_SESSION["user_bg_color"] = $background_id;

    // Create a database connection (modify these values as needed)
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Update the user's background in the database

    $sql = "UPDATE user SET theme = $background_id WHERE user_id = $user_id";
    if ($conn->query($sql) === TRUE) {
        header("Location: home-page.php");
        exit(); // Ensure script stops execution after the header redirect
    } else {
        echo "Error updating background: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid request";
}
?>
