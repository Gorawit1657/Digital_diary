<?php
// Start the session
session_start();

// Check if the user is logged in by verifying if the 'user_id' session variable exists
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_username = $_SESSION['user_username'];
    $user_font = $_SESSION["user_font"];
    $user_bg_color = $_SESSION["user_bg_color"];
    $user_paper_color = $_SESSION["user_paper_color"];

    if ($user_bg_color == 1) {
        $user_bg_color_code = '#a7d7c5';
        $user_subbg_color_code = '#c1e3d6';
    } elseif ($user_bg_color == 2) {
        $user_bg_color_code = '#3388ff';
        $user_subbg_color_code = '#77ccff';
    } elseif ($user_bg_color == 3) {
        $user_bg_color_code = '#fea95e';
        $user_subbg_color_code = '#f9ddb1';
    }

    if ($user_paper_color == 1) {
        $user_pad_code = '#f6fbf9';
    } elseif ($user_paper_color == 2) {
        $user_pad_code = '#333333';
    } elseif ($user_paper_color == 3) {
        $user_pad_code = '#f9e4bc';
    }

    if ($user_font == 1) {
        $user_font_code = 'Arial';
    } elseif ($user_font == 2) {
        $user_font_code = 'Times New Roman';
    } elseif ($user_font == 3) {
        $user_font_code = 'Courier New';
    }

    // You can now use $user_id in your page
} else {
    // If the 'user_id' session variable doesn't exist, the user is not logged in
    // You can handle this situation by redirecting them to the login page or displaying an error message
    header('Location: login.php');
    exit();
}
?>

<?php
// goal_details.php

$diary_id = $_GET['diary_id'];
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "digital_diary";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT `diary_id`,`diary_title`,`diary_date`,`diary_content` FROM `diary` WHERE diary_id= $diary_id ORDER BY `diary_date` ASC";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Loop through all rows
    while ($row = $result->fetch_assoc()) {
        $diary_title = $row["diary_title"];
        $diary_date = $row["diary_date"];
        $user_diary_content = $row["diary_content"];

    }
} else {
    // No match, return id = 0
    echo "No match, id = 0";
}

$conn->close();
?>



<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title> comment</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400%2C500"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400%2C500"/>
  <link rel="stylesheet" href="./styles/comment.css"/>

    <script>
       document.addEventListener("DOMContentLoaded", function() {
        var mainbg = document.querySelector('.comment-etg');
        var subbg1 = document.querySelector('.rectangle-7-zhe');
        var subbg2 = document.querySelector('.rectangle-8-KV2');
        var pad_location = document.querySelector('.rectangle-1-HTn');
        var font_title = document.querySelector('.writing-01-aLQ');
        var font_description = document.querySelector('.welcome-to-your-new-journal-not-sure-where-to-start-take-a-few-minutes-to-jot-down-the-reasons-why-you-want-to-journal-in-the-future-if-you-need-motivation-to-keep-writing-you-can-come-back-to-re-read-this-first-entry-and-remember-why-you-started-in-the-first-place-gnk');

        var user_bg_color_code = "<?php echo $user_bg_color_code; ?>";
        var user_subbg_color_code = "<?php echo $user_subbg_color_code; ?>";
        var user_pad_code = "<?php echo $user_pad_code; ?>";
        var user_font_code = "<?php echo $user_font_code; ?>";

        mainbg.style.backgroundColor = user_bg_color_code;
        subbg1.style.backgroundColor = user_subbg_color_code;
        subbg2.style.backgroundColor = user_subbg_color_code;
        pad_location.style.backgroundColor = user_pad_code;
        font_title.style.fontFamily = user_font_code;
        font_description.style.fontFamily = user_font_code;

    });
  </script>
</head>


<body>
<div class="comment-etg">
  <div class="rectangle-7-zhe">
  </div>
  <div class="rectangle-8-KV2">
  </div>
  <div class="rectangle-26-TbE">
  </div>
  <a href="setting.php" style="text-decoration: none;">
  <div class="user01-bBe">
    <img class="vector-uCL" src="./assets/vector-LbJ.png"/>
    <p class="user01-r7a"><?php echo $user_username; ?></p>
    <img class="vector-10-xwJ" src="./assets/vector-10-vnL.png"/>
  </div>
  </a>

  <div class="rectangle-1-HTn">
  </div>
 
  <a href="home-page.php" style="text-decoration: none;">
    <img class="vector-Cak" src="./assets/vector-9MJ.png"/>
  </a>

  <div class="group-9-wHS">

    <div class="auto-group-s53y-Tma">
      <p class="writing-01-aLQ"><?php echo $diary_title; ?></p>

    </div>
      
    <p class="user01-tue-10-23-2023-at-0-27pm-bFW"><?php echo $diary_date; ?></p>

    <p class="welcome-to-your-new-journal-not-sure-where-to-start-take-a-few-minutes-to-jot-down-the-reasons-why-you-want-to-journal-in-the-future-if-you-need-motivation-to-keep-writing-you-can-come-back-to-re-read-this-first-entry-and-remember-why-you-started-in-the-first-place-gnk"><?php echo $user_diary_content ?></p>
    
      <img class="vector-2-HXe" src="./assets/vector-2-2LG.png"/>


    <div class="auto-group-xqc3-cpp">
      <div class="comment-Lkp">
        <p class="comments-sEx">Comments</p>

        <div class="comment_box">

            <?php
            echo "<form action='new_comment_process.php?diary_id=" . $diary_id . "' method='POST'>";
            $servername = "localhost";
            $username = "root";
            $password = "root";
            $dbname = "digital_diary";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT `comment_date`, `comment_content` FROM `comment` WHERE  diary_id=$diary_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Loop through all row

                while ($row = $result->fetch_assoc()) {
                    $comment_date = $row["comment_date"];
                    $comment_content = $row["comment_content"];


                    // Display the data in a box


                    echo "<div class='comment02-afA'>";
                    echo "<img class='vector-JLG' src='./assets/vector-6vC.png'/>";
                    echo "<div class='auto-group-y1bq-ppQ'>";
                    echo "<div class='auto-group-fyhm-ySQ'>";
                    echo "<p class='user01-XD2'>$user_username</p>";
                    echo "</div>";
                    echo "<p class='comment-02-LRN'>$comment_content</p>";
                    echo "</div>";
                    echo "</div>";
                }
               
            } else {

            }

            $conn->close();
            ?>





        </div>
      </div>



    </div>
    
    <div class="add-comment-9Bn">
      <img class="vector-Ujr" src="./assets/vector-2sz.png"/>
      <input type="text" name="add_comment_tb" id="add_comment_tb" placeholder="Add Comment" class="auto-group-wcy9-cbA" />
      <button type="submit" style="background: transparent; border: none; padding: 0; cursor: pointer;">
        <img src="./assets/vector-vZN.png" class="vector-qip" alt="Submit Comment"/>
      </button>
    </div>
    </form>

  </div>
</div>
</body>