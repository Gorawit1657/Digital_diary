

<?php
// Start the session
session_start();

// Check if the user is logged in by verifying if the 'user_id' session variable exists
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_username = $_SESSION['user_username'];
    $user_font = $_SESSION["user_font"];
    $user_bg_color = $_SESSION["user_bg_color"];
    $user_paper_color = $_SESSION["user_paper_color"];

    if ($user_bg_color == 1) {
        $user_bg_color_code = '#a7d7c5';
        $user_subbg_color_code = '#c1e3d6';
    } elseif ($user_bg_color == 2) {
        $user_bg_color_code = '#3388ff';
        $user_subbg_color_code = '#77ccff';
    } elseif ($user_bg_color == 3) {
        $user_bg_color_code = '#fea95e';
        $user_subbg_color_code = '#f9ddb1';
    }

    // You can now use $user_id in your page
} else {
    // If the 'user_id' session variable doesn't exist, the user is not logged in
    // You can handle this situation by redirecting them to the login page or displaying an error message
    header('Location: login.php');
    exit();
}
?>



<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>on going</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400"/>
  <link rel="stylesheet" href="./styles/goal-complete.css"/>

     <script>
       document.addEventListener("DOMContentLoaded", function() {
        var mainbg = document.querySelector('.on-going-xye');
        var subbg1 = document.querySelector('.rectangle-7-iC8');
        var subbg2 = document.querySelector('.rectangle-8-Dua');
        var user_bg_color_code = "<?php echo $user_bg_color_code; ?>";
        var user_subbg_color_code = "<?php echo $user_subbg_color_code; ?>";

        mainbg.style.backgroundColor = user_bg_color_code;
        subbg1.style.backgroundColor = user_subbg_color_code;
        subbg2.style.backgroundColor = user_subbg_color_code;
    });
  </script>
</head>

<body>
<div class="on-going-xye">
  <div class="rectangle-7-iC8">
  </div>
  <div class="rectangle-8-Dua">
  </div>
  <div class="rectangle-26-AK2">
  </div>
  <a href="setting.php" style="text-decoration: none;">
      <div class="user01-tF2">
        <img class="vector-b9S" src="./assets/vector-zZe.png"/>
        <p class="user01-jFe"><?php echo $user_username; ?></p>
        <img class="vector-10-dbv" src="./assets/vector-10-Kov.png"/>
      </div>
  </a>
  <div class="group-2-kgY">
    <div class="auto-group-zzbm-Rng">
      <div class="auto-group-zjc3-K7N">
        <p class="on-going-PmS">Completed</p>

        <div class="display_box" >
          

          <?php
          $servername = "localhost";
          $username = "root";
          $password = "root";
          $dbname = "digital_diary";

          $conn = new mysqli($servername, $username, $password, $dbname);

          // Check connection
          if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
          }

          $sql = "SELECT `goal_id`,`goal_title`,`goal_description`,`goal_date`,`goal_start_time`,`goal_end_time` FROM `goal` WHERE user_id = $user_id and goal_complete=1 ORDER BY `goal_date`,`goal_end_time` ASC";
          $result = $conn->query($sql);

          if ($result->num_rows > 0) {
              // Loop through all rows
              while ($row = $result->fetch_assoc()) {
                  $goal_id = $row["goal_id"];
                  $goal_title = $row["goal_title"];
                  $goal_description = $row["goal_description"];
                  $user_goal_date = $row["goal_date"];
                  $user_goal_start_time = $row["goal_start_time"];
                  $user_goal_end_time = $row["goal_end_time"];

                  // Display the data in a box
                  echo "<div class='goal_box'>";
                  echo "<div class='goal_detail_grouping'>";
                  echo "<p class='goal_title'>$goal_title</p>";
                  echo "<p class='goal_date'>Deadline: $user_goal_date</p>";
                  echo " <p class='goal_time'>$user_goal_start_time - $user_goal_end_time</p>";
                  echo "</div>";

                  echo "</div>";

              }
          } else {

          }

          $conn->close();
          ?>





          


        </div>




      </div>
    </div>
  </div>
  <a href="goal-planner.php" style="text-decoration: none;">
  <img class="vector-ePi" src="./assets/vector-E7z.png"/>
  </a>
</div>
</body>