<?php
// Start the session
session_start();

// Check if the user is logged in by verifying if the 'user_id' session variable exists
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_username = $_SESSION['user_username'];
    $user_font = $_SESSION["user_font"];
    $user_bg_color = $_SESSION["user_bg_color"];
    $user_paper_color = $_SESSION["user_paper_color"];

    if ($user_bg_color == 1) {
        $user_bg_color_code = '#a7d7c5';
        $user_subbg_color_code = '#c1e3d6';
    } elseif ($user_bg_color == 2) {
        $user_bg_color_code = '#3388ff';
        $user_subbg_color_code = '#77ccff';
    } elseif ($user_bg_color == 3) {
        $user_bg_color_code = '#fea95e';
        $user_subbg_color_code = '#f9ddb1';
    }

    // You can now use $user_id in your page
} else {
    // If the 'user_id' session variable doesn't exist, the user is not logged in
    // You can handle this situation by redirecting them to the login page or displaying an error message
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>entry2</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400%2C500"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400%2C500"/>
  <link rel="stylesheet" href="./styles/entry2.css"/>

    <script>
       document.addEventListener("DOMContentLoaded", function() {
        var mainbg = document.querySelector('.entry2-ch6');
        var subbg1 = document.querySelector('.rectangle-7-Ld6');
        var subbg2 = document.querySelector('.rectangle-8-rbS');
        var user_bg_color_code = "<?php echo $user_bg_color_code; ?>";
        var user_subbg_color_code = "<?php echo $user_subbg_color_code; ?>";

        mainbg.style.backgroundColor = user_bg_color_code;
        subbg1.style.backgroundColor = user_subbg_color_code;
        subbg2.style.backgroundColor = user_subbg_color_code;
    });
  </script>
</head>


<body>
<div class="entry2-ch6">
  <div class="rectangle-7-Ld6">
  </div>
  <div class="rectangle-8-rbS">
  </div>
  <div class="rectangle-26-nzt">
  </div>
    <a href="setting.php" style="text-decoration: none;">
  <div class="user01-XSg">
    <img class="vector-eGQ" src="./assets/vector-Zj6.png"/>
    <p class="user01-zLG"><?php echo $user_username; ?></p>
    <img class="vector-10-Jbr" src="./assets/vector-10-n6U.png"/>
  </div>
  </a>

  <div class="rectangle-1-EkQ">
  </div>

  <img class="vector-2-7Bv" src="./assets/vector-2-zEt.png"/>
  <p class="entry-dg4">Entry</p>
  <p class="last-modified-XWY">Last Modified</p>



  <a href="home-page.php" style="text-decoration: none;">
  <img class="vector-wqA" src="./assets/vector-EGx.png"/>
  </a>

  
  <div class="entry_box">

      <?php
      $servername = "localhost";
      $username = "root";
      $password = "root";
      $dbname = "digital_diary";

      $conn = new mysqli($servername, $username, $password, $dbname);

      // Check connection
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      $sql = "SELECT `diary_id`,`diary_title`,`diary_date`,`diary_content` FROM `diary` WHERE user_id = $user_id ORDER BY `diary_date` ASC";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
          // Loop through all rows
          while ($row = $result->fetch_assoc()) {
              $diary_title = $row["diary_title"];
              $diary_date = $row["diary_date"];
              $user_diary_content = $row["diary_content"];

              // Display the data in a box
              echo "<a href='comment.php?diary_id={$row['diary_id']}'style='text-decoration: none;'>";
              echo "<div class='writing-01-Cm6'>";
              echo "  <div class='auto-group-y8lt-Rdr'>";
              echo "    <p class='writing-02-4Rv'>$diary_title</p>";
              echo "  </div>";
              echo "  <div class='diary_detail''>";
              echo "      <p class='tue-10-24-2023-at-4-27pm-AUx'>$diary_date</p>";
              echo "  </div>";
              echo "</div>";
              echo "</a>";
          }
      } else {

      }

      $conn->close();
      ?>




  </div>





    

   

  <a href="writing-pad.php" style="text-decoration: none;">
  <img class="vector-Cfr" src="./assets/vector-Adn.png"/>
  </a>
</div>
</body>