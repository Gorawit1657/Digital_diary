<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>setting page 4</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Courier+New%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arial%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Times+New+Roman%3A400"/>
  <link rel="stylesheet" href="./styles/setting-page-4.css"/>
</head>
<body>
<div class="setting-page-4-Bcm">
  <div class="rectangle-7-161">
  </div>
  <div class="rectangle-8-H3X">
  </div>
  <div class="group-3-c5o">
    <p class="entry-font-2Hw">ENTRY FONT</p>
    <div class="auto-group-62pb-fbo">   

      <button style="background: #f6fbf9; width: 35rem; height: 35rem;" onclick="redirectToBackgroundUpdate(1)">
      <div class="arial-wZK">
        <p class="entry-title-MB7">Entry Title</p>
        <p style="font-size: 2rem;
           position:relative;
           left:-20rem;
           width:33rem;
           top:4rem;
           font-weight: 400;
           line-height: 1.2575;
           color: #a0a1a5;
           font-family: 'Arial' , 'Source Sans Pro'">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus vitae tellus molestie, egestas mi in, tempor quam. Fusce ac suscipit velit. Mauris ac nisi eget nisi luctus dignissim. </p>

      </div>
      </button>

      <button style="background: #f6fbf9; width: 35rem; height: 35rem;" onclick="redirectToBackgroundUpdate(2)">
      <div class="arial-G3B">
        <p class="entry-title-cuf">Entry Title</p>
        <p style="font-size: 2rem;
           position:relative;
           left:-20rem;
           width:33rem;
           top:4rem;
           font-weight: 400;
           line-height: 1.2575;
           color: #a0a1a5;
           font-family: 'Times New Roman' , 'Source Sans Pro'">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus vitae tellus molestie, egestas mi in, tempor quam. Fusce ac suscipit velit. Mauris ac nisi eget nisi luctus dignissim. </p>
      </div>
      </button>


      <button style="background: #f6fbf9; width: 35rem; height: 35rem;" onclick="redirectToBackgroundUpdate(3)">
      <div class="arial-vfT">
        <p class="entry-title-RPF">Entry Title</p>
        <p style="font-size: 2rem;
           position:relative;
           top:6rem;
           font-weight: 400;
           line-height: 1.2575;
           color: #a0a1a5;
           font-family: Courier New, 'Source Sans Pro'">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus vitae tellus molestie, egestas mi in, tempor quam. Fusce ac suscipit velit. Mauris ac nisi eget nisi luctus dignissim. </p>
      </div>
      </button>


    </div>



    <p class="now-lets-customize-the-in-side-of-your-journal-JT3">Now Let’s customize the in side of your journal.</p>
    <div class="auto-group-u94v-PDb">
      <p class="arial-K7F">Arial</p>
      <p class="times-new-roman-Ezu">Times New Roman</p>
      <p class="courier-new-mjw">Courier New</p>
    </div>
    <img class="vector-svg-button-7J1" src="./assets/vector-svg-button-f3w.png"/>
  </div>

      <script>
    function redirectToBackgroundUpdate(id) {
      window.location.href = 'font_update_process.php?id=' + id;
    }
  </script>
</div>
</body>