<?php
// Start the session
session_start();

// Check if the user is logged in by verifying if the 'user_id' session variable exists
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_username = $_SESSION['user_username'];
    $user_font = $_SESSION["user_font"];
    $user_bg_color = $_SESSION["user_bg_color"];
    $user_paper_color = $_SESSION["user_paper_color"];

    if ($user_bg_color == 1) {
        $user_bg_color_code = '#a7d7c5';
        $user_subbg_color_code = '#c1e3d6';
    } elseif ($user_bg_color == 2) {
        $user_bg_color_code = '#3388ff';
        $user_subbg_color_code = '#77ccff';
    } elseif ($user_bg_color == 3) {
        $user_bg_color_code = '#fea95e';
        $user_subbg_color_code = '#f9ddb1';
    }

    // You can now use $user_id in your page
} else {
    // If the 'user_id' session variable doesn't exist, the user is not logged in
    // You can handle this situation by redirecting them to the login page or displaying an error message
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>goal planner</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400"/>
  <link rel="stylesheet" href="./styles/goal-planner.css"/>

    <script>
       document.addEventListener("DOMContentLoaded", function() {
        var mainbg = document.querySelector('.goal-planner-EoJ');
        var subbg1 = document.querySelector('.rectangle-8-Hma');
        var subbg2 = document.querySelector('.rectangle-7-Awr');
        var user_bg_color_code = "<?php echo $user_bg_color_code; ?>";
        var user_subbg_color_code = "<?php echo $user_subbg_color_code; ?>";

        mainbg.style.backgroundColor = user_bg_color_code;
        subbg1.style.backgroundColor = user_subbg_color_code;
        subbg2.style.backgroundColor = user_subbg_color_code;
    });
  </script>
</head>
<body>
<div class="goal-planner-EoJ">
  <div class="rectangle-7-Awr">
  </div>
  <div class="rectangle-8-Hma">
  </div>
  <div class="rectangle-26-ERv">
  </div>
  <a href="home-page.php" style="text-decoration: none;">
  <img class="vector-A4g" src="./assets/vector-pvc.png"/>
  </a>
  <a href="setting.php" style="text-decoration: none;">
  <div class="user01-6DE">
    <img class="vector-1LC" src="./assets/vector-JYG.png"/>
    <p class="user01-Z6p"><?php echo $user_username; ?></p>
    <img class="vector-10-4pG" src="./assets/vector-10-xfA.png"/>
  </div>
  </a>
  <a href="new-goal.php" style="text-decoration: none;">
  <div class="new-goal-zT2">
    <div class="auto-group-rtqu-u4C">New Goal</div>
    <img class="subtract-ZPe" src="./assets/subtract.png"/>
  </div>
  </a>

  <a href="on-going.php" style="text-decoration: none;">
  <div class="on-goning-sfE">
    <div class="auto-group-8z59-Nrt">On Going</div>
    <img class="vector-e3i" src="./assets/vector-UPa.png"/>
  </div>
  </a>
  <a href="completed.php" style="text-decoration: none;">
  <div class="completed-xaC">
    <div class="auto-group-45cp-Gqn">Completed</div>
    <img class="subtract-wwv" src="./assets/subtract-6Wt.png"/>
  </div>
  </a>
</div>
</body>