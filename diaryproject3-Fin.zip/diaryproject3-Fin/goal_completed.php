<?php
// Start the session
session_start();

// Check if the user is logged in by verifying if the 'user_id' session variable exists
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    // Other session variables...

    // You can now use $user_id in your page
} else {
    // If the 'user_id' session variable doesn't exist, the user is not logged in
    // You can handle this situation by redirecting them to the login page or displaying an error message
    header('Location: login.php');
    exit();
}

// Check if 'goal_id' is set in the URL
if (isset($_GET['goal_id'])) {
    $goal_id = $_GET['goal_id'];

    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Update the goal_complete column to 1
    $sql = "UPDATE `goal` SET `goal_complete` = 1 WHERE `user_id` = '$user_id' AND `goal_id` = '$goal_id'";

    $result = $conn->query($sql);

    if (!$result) {
        die("Error updating goal completion: " . $conn->error);
    }

    $conn->close();

    // Redirect back to the page where the goal was completed
    header("Location: goal-planner.php");
    exit();
} else {
    // Redirect to a page with an error message or handle accordingly
    header("Location: error.php");
    exit();
}
?>
