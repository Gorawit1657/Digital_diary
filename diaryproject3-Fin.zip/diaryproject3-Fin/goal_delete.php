<?php
// goal_delete_process.php

$goal_id = $_GET['goal_id'];

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "digital_diary";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "DELETE FROM `goal` WHERE goal_id = $goal_id";

if ($conn->query($sql) === TRUE) {
    // Record deleted successfully, redirect back to test3.php
    header('Location: goal-planner.php');
    exit();
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
