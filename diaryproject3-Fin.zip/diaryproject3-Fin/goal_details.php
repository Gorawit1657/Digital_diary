<?php
// goal_details.php

$goal_id = $_GET['goal_id'];

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "digital_diary";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT `goal_title`,`goal_description`,`goal_date`,`goal_start_time`,`goal_end_time` FROM `goal` WHERE goal_id = $goal_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Loop through all rows
    while ($row = $result->fetch_assoc()) {
        $goal_title = $row["goal_title"];
        $goal_description = $row["goal_description"];
        $goal_date = $row["goal_date"];
        $goal_start_time = $row["goal_start_time"];
        $goal_end_time = $row["goal_end_time"];

    }
} else {
    // No match, return id = 0
    echo "No match, id = 0";
}

$conn->close();
?>


<?php
// Start the session
session_start();

// Check if the user is logged in by verifying if the 'user_id' session variable exists
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_username = $_SESSION['user_username'];
    $user_font = $_SESSION["user_font"];
    $user_bg_color = $_SESSION["user_bg_color"];
    $user_paper_color = $_SESSION["user_paper_color"];

    if ($user_bg_color == 1) {
        $user_bg_color_code = '#a7d7c5';
        $user_subbg_color_code = '#c1e3d6';
    } elseif ($user_bg_color == 2) {
        $user_bg_color_code = '#3388ff';
        $user_subbg_color_code = '#77ccff';
    } elseif ($user_bg_color == 3) {
        $user_bg_color_code = '#fea95e';
        $user_subbg_color_code = '#f9ddb1';
    }

    // You can now use $user_id in your page
} else {
    // If the 'user_id' session variable doesn't exist, the user is not logged in
    // You can handle this situation by redirecting them to the login page or displaying an error message
    header('Location: login.php');
    exit();
}
?>



<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>new goal</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400%2C700"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400%2C700"/>
  <link rel="stylesheet" href="./styles/goal_detail.css"/>
  <script>
       document.addEventListener("DOMContentLoaded", function() {
        var mainbg = document.querySelector('.new-goal-Q3S');
        var subbg1 = document.querySelector('.rectangle-7-Y9e');
        var subbg2 = document.querySelector('.rectangle-8-rw2');
        var user_bg_color_code = "<?php echo $user_bg_color_code; ?>";
        var user_subbg_color_code = "<?php echo $user_subbg_color_code; ?>";

        mainbg.style.backgroundColor = user_bg_color_code;
        subbg1.style.backgroundColor = user_subbg_color_code;
        subbg2.style.backgroundColor = user_subbg_color_code;
    });
  </script>
</head>


<body>
<div class="new-goal-Q3S">
  <div class="rectangle-7-Y9e">
  </div>
  <div class="rectangle-8-rw2">
  </div>
  <div class="rectangle-26-oLU">
  </div>
  <a href="setting.php" style="text-decoration: none;">
  <div class="user01-L5W">
    <img class="vector-rZe" src="./assets/vector-koi.png"/>
    <p class="user01-zvk"><?php echo $user_username; ?></p>
    <img class="vector-10-X9z" src="./assets/vector-10-EEC.png"/>
  </div>
  </a>
  <div class="group-2-eEc">
    <div class="auto-group-kjhz-89n">
      <div class="title-eP2">
        <div class="rectangle-2-nVE">
        </div>
        <p class="tittle-BGU">Title</p>
        <div class="rectangle-2-nVE"><?php echo $goal_title; ?> </div>
      </div>
      <p class="new-goal-gU8"></p>
    </div>
    <div class="date-PNY">
      <p class="date-Wxx">Date</p>
        <div class="auto-group-cngj-EPA"><?php echo $goal_date; ?> </div>
    </div>
    <div class="date-Tmi">
      <div class="auto-group-wnkt-CUQ">
        <p class="time-YYG">Time</p>
        <div class="auto-group-s9l7-sKe"><?php echo $goal_start_time; ?></div>
      </div>
      <p class="to-j6x">to</p>

      <div class="auto-group-uu4p-rSU"><?php echo $goal_end_time; ?> </div>
    </div>
    <div class="date-UCx">
      <p class="description-1Ct">Description</p>
      <div class="auto-group-gjkv-vKr"><?php echo $goal_description; ?> </div>
    </div>
    <div class="auto-group-j1ss-AEC">
      <div class="create-button-6tY">
        <a href="goal_delete.php?goal_id=<?php echo $goal_id; ?>" style="text-decoration: none;">
        <div class="create-acc-r72">Delete</div>
        </a>
      </div>
      <div class="save-LH6">
        <a href="goal_completed.php?goal_id=<?php echo $goal_id; ?>" style="text-decoration: none;">
        <div class="create-acc-Vfn">Complete</div>
        <</a>
      </div>
    </div>
  </div>
  <a href="on-going.php" style="text-decoration: none;">
  <img class="vector-MCC" src="./assets/vector-LNc.png"/>
  </a>
</div>
</body>