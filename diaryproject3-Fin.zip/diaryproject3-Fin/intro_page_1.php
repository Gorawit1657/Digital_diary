

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>setting page 1</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Barlow+Condensed%3A500"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400%2C500%2C700"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400%2C500%2C700"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=B612%3A700"/>
  <link rel="stylesheet" href="./styles/intro_page_1.css"/>
</head>
<body>
<div class="setting-page-1-XjN">
  <div class="rectangle-7-g6U">
  </div>
  <div class="rectangle-8-oRz">
  </div>
  <div class="group-2-8z4">
    <div class="rectangle-1-58c">
    </div>
    <p class="textgroup">
      <span class="textgroup-sub-0">
      Don&#39;t let your emotions
      <br/>
       get in the way of your life
      <br/>
      
      <br/>
      
      </span>
      <span class="textgroup-sub-1">
      Record Your Emotions 
      <br/>
      Get To Know Yourself
      <br/>
      
      </span>
      <span class="textgroup-sub-2">
      
      <br/>
      
      <br/>
      
      <br/>
      
      <br/>
      
      </span>
      <span class="textgroup-sub-3">
      
      <br/>
      
      </span>
    </p>
    <p class="welcome-XaG">Welcome</p>
    <div class="page-d7W">
      <img class="image-1-Z1A" src="./assets/image-1.png"/>
      <img class="image-2-gba" src="./assets/image-2.png"/>
      <img class="image-3-RZA" src="./assets/image-3.png"/>
    </div>
    <a href="intro_page_3.php" style="text-decoration: none;">
    <img class="arrowrightoutlined-Mxc" src="./assets/arrowrightoutlined-63z.png"/>
    </a>
  </div>
</div>



</body>