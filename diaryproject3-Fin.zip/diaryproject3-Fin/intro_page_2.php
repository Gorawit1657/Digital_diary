<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>setting page 2</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arial%3A400"/>
  <link rel="stylesheet" href="./styles/intro_page_2.css"/>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    var fontSelector = document.getElementById('font-selector');
    var radios = document.querySelectorAll('input[type="radio"][name="background"]');
    var padRadios = document.querySelectorAll('input[type="radio"][name="pad_style"]');
    var background_selectedColor = "#a7d7c5"; // Default background color
    var pad_selectedColor = "#f6fbf9"; // Default pad style color

    for (var i = 0; i < radios.length; i++) {
        radios[i].addEventListener('change', function() {
            background_selectedColor = this.value;
            updateBackgroundColors();
        });
    }

    for (var i = 0; i < padRadios.length; i++) {
        padRadios[i].addEventListener('change', function() {
            pad_selectedColor = this.value;
            updateBackgroundColors();
        });
    }

    function updateBackgroundColors() {
        var settingPage = document.querySelector('.setting-page-2-R4C');
        var rectangle7 = document.querySelector('.rectangle-7-ZAQ');
        var rectangle8 = document.querySelector('.rectangle-8-swn');
        var padbgPage = document.querySelector('.example-4Xi');

        settingPage.style.backgroundColor = background_selectedColor;

        if (background_selectedColor === '#a7d7c5') {
            rectangle7.style.backgroundColor = '#c1e3d6';
            rectangle8.style.backgroundColor = '#c1e3d6';
        } else if (background_selectedColor === '#3388ff') {
            rectangle7.style.backgroundColor = '#77ccff';
            rectangle8.style.backgroundColor = '#77ccff';
        } else if (background_selectedColor === '#fea95e') {
            rectangle7.style.backgroundColor = '#f9ddb1';
            rectangle8.style.backgroundColor = '#f9ddb1';
        }

        padbgPage.style.backgroundColor = pad_selectedColor;
    }

    fontSelector.addEventListener('change', function() {
      var selectedFont = this.value;
      var exampleText = document.querySelector('.example-4Xi .your-entry-here-n6L');
      var titleText = document.querySelector('.example-4Xi .entry-title-wtL');
      var dateText = document.querySelector('.example-4Xi .auto-group-bgjm-BMS .tue-10-24-2023-eVv');
      var fontText = document.querySelector('.group-3-RCc .auto-group-xjph-y7e .entry-font-rKr .auto-group-nct5-JSk .font_combobox');

      titleText.style.fontFamily = selectedFont;
      dateText.style.fontFamily = selectedFont;
      exampleText.style.fontFamily = selectedFont;
      fontText.style.fontFamily = selectedFont;
      var xhr = new XMLHttpRequest();
      xhr.open('POST', 'process_font.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
          console.log(xhr.responseText); // You can handle the response here
        }
      };
      xhr.send('selectedFont=' + encodeURIComponent(selectedFont));
    });
  });
  </script>

</head>
<body>
<div class="setting-page-2-R4C">
  <div class="rectangle-7-ZAQ">
  </div>
  <div class="rectangle-8-swn">
  </div>
  <div class="group-3-RCc">
    <p class="now-lets-customize-the-in-side-of-your-journal-WUx">Now Let’s customize the in side of your journal.</p>
    <div class="auto-group-xjph-y7e">
      <div class="horizontal-line-u1J">
        <img class="vector-1-pPA" src="./assets/vector-1-tS4.png"/>
        <img class="vector-2-9wE" src="./assets/vector-2-eQg.png"/>
        <img class="vector-3-hhr" src="./assets/vector-3-qDi.png"/>
      </div>
      <div class="entry-font-rKr">
        <p class="entry-font-ame">ENTRY FONT</p>
        <div class="auto-group-nct5-JSk">
          <select id="font-selector" class="font_combobox">
            <option value="Arial" class="arial_font">Arial</option>
            <option value="Times New Roman" class="timenewroman_font">Times New Roman</option>
            <option value="Courier New" class="couriernew_font">Courier New</option>
          </select>
        </div>
      </div>
      <div class="journal-back-ground-CAk">
        <p class="journal-background-7Hi">JOURNAL BACKGROUND</p>
          <label>
            <input type="radio" name="background" value="#a7d7c5" checked>
            <div class="radio-button" style="background-color: #a7d7c5;"></div>
          </label>
          <label>
            <input type="radio" name="background" value="#3388ff">
            <div class="radio-button" style="background-color: #3388ff;"></div>
          </label>
          <label>
            <input type="radio" name="background" value="#fea95e">
            <div class="radio-button" style="background-color: #fea95e;"></div>
          </label>
      </div>
    </div>
    <div class="pad-style-xZE">
      <p class="pad-style-HbW">PAD STYLE</p>
      <label>
            <input type="radio" name="pad_style" value="#f6fbf9" checked>
            <div class="radio-button" style="background-color: #f6fbf9;"></div>
          </label>
          <label>
            <input type="radio" name="pad_style" value="#333333">
            <div class="radio-button" style="background-color: #333333;"></div>
          </label>
          <label>
            <input type="radio" name="pad_style" value="#f9e4bc">
            <div class="radio-button" style="background-color: #f9e4bc; "></div>
          </label>
    </div>
    <div class="auto-group-5hjr-7qS">
      <div class="page-SMv">
        <img class="image-1-NFa" src="./assets/image-1-Quv.png"/>
        <img class="image-5-Vb6" src="./assets/image-5.png"/>
        <img class="image-4-RDr" src="./assets/image-4.png"/>
      </div>
      <a href="process_font.php" style="text-decoration: none;">
      <img class="arrowrightoutlined-kX2" src="./assets/arrowrightoutlined.png"/>
      </a>
    </div>
  </div>
  <div class="example-4Xi">
    <div class="auto-group-bgjm-BMS">
      <img class="date-Wec" src="./assets/date-dRi.png"/>
      <p class="tue-10-24-2023-eVv">Tue. 10/24/2023 </p>
    </div>
    <p class="your-entry-here-n6L">Your entry here</p>
    <img class="vector-1-Uzk" src="./assets/vector-1-c5N.png"/>
    <img class="vector-2-QtQ" src="./assets/vector-2-n72.png"/>
    <p class="entry-title-wtL">Entry Title</p>
  </div>
</div>

</body>