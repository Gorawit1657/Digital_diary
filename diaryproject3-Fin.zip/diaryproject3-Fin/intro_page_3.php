<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>setting page 3</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=B612%3A700"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A700"/>
  <link rel="stylesheet" href="./styles/intro_page_3.css"/>
</head>
<body>
<div class="setting-page-3-qcU">
  <div class="rectangle-7-PP6">
  </div>
  <div class="rectangle-8-hua">
  </div>
  <div class="group-3-SsA">
    <p class="everything-is-ready-start-your-journey-on-KRA">
    Everything is ready
    <br/>
    Start your journey on
    <br/>
    
    </p>
    <p class="record-your-happiness-oLL">RECORD YOUR HAPPINESS</p>
    <div class="auto-group-8yfh-iCQ">
      <div class="page-Su6">
        <img class="image-5-xsS" src="./assets/image-5-i8Q.png"/>
        <img class="image-7-6ye" src="./assets/image-7.png"/>
        <img class="image-6-qgL" src="./assets/image-6.png"/>
      </div>
      <a href="home-page.php" style="text-decoration: none;">
      <img class="arrowrightoutlined-n5n" src="./assets/arrowrightoutlined-Eek.png"/>
      </a>
    </div>
  </div>
</div>
</body>