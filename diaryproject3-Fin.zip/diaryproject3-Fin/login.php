<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>login</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400"/>
  <link rel="stylesheet" href="./styles/login.css"/>
</head>
<body>
<div class="login-NHv">
  <div class="rectangle-7-7WQ">
  </div>
  <div class="rectangle-8-qBW">
  </div>
  <div class="form-Mfe">
    <p class="sign-in-3Ha">Sign in</p>
    <form action="login_process.php" method="POST">
    <input type="text" name="signin_user_username" id="signin_user_username" placeholder="USERNAME" class="username-vcG" required/>
    <input type="text" name="signin_user_password" id="signin_user_password" placeholder="PASSWORD" class="password-xor" required/>
    <button class="login-btn-zVe">login</button>
    </form>
    <div class="register-Cbi">
      <p class="not-registered-yet-8VN">Not registered yet?</p>
      <span class="sign-up-here-2qe">
            <a href="register.php">Sign-up HERE!!</a>
        </span>
    </div>
  </div>
</div>
</body>