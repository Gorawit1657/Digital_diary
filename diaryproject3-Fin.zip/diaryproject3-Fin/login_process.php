<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $login_username = $_POST["signin_user_username"];
    $login_password = $_POST["signin_user_password"];

    // Create a database connection (modify these values as needed)
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT user.user_id, username, email, password, font, theme, pad_style
                            FROM log_in
                            INNER JOIN user ON log_in.user_id=user.user_id
                            WHERE log_in.username = ?");
    $stmt->bind_param("s", $login_username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Match found, retrieve the user's information
        $row = $result->fetch_assoc();
        $storedPassword = $row["password"];

        // Verify the entered password against the stored hashed password
        if (password_verify($login_password, $storedPassword)) {
            // Passwords match, proceed with login
            session_start();

            // Store user information in session variables
            $_SESSION['user_id'] = $row["user_id"];
            $_SESSION['user_username'] = $row["username"];
            $_SESSION['user_email'] = $row["email"];
            $_SESSION["user_font"] = $row["font"];
            $_SESSION["user_bg_color"] = $row["theme"];
            $_SESSION["user_paper_color"] = $row["pad_style"];


            // Redirect to the home page
            header('Location: home-page.php');
            exit();
        } else {
            // Passwords do not match
            header('Location: login.php');
        }
    } else {
        // User not found
        echo "User not found";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
