<?php

function encryptPassword($password)
{
    $key = "your_secret_key"; // Change this to a secure key
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $encryptedPassword = openssl_encrypt($password, 'aes-256-cbc', $key, 0, $iv);
    return base64_encode($encryptedPassword . '::' . $iv);
}

function decryptPassword($encryptedPassword)
{
    $key = "your_secret_key"; // Change this to the same key used for encryption
    list($encryptedPassword, $iv) = explode('::', base64_decode($encryptedPassword), 2);
    return openssl_decrypt($encryptedPassword, 'aes-256-cbc', $key, 0, $iv);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $login_username = $_POST["signin_user_username"];
    $login_password = encryptPassword($_POST["signin_user_password"]);

    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT user.user_id, username, email, password, font, theme, pad_style FROM log_in INNER JOIN user ON log_in.user_id=user.user_id WHERE username = '$login_username'";
    $result = $conn->query($sql);

        echo $row["password"];
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $storedPassword = $row["password"];
            if (decryptPassword($storedPassword) == $login_password) {
                // Passwords match, proceed with login
                session_start();
                // Store user information in session variables
                $_SESSION['user_id'] = $row["user_id"];
                $_SESSION['user_username'] = $row["username"];
                $_SESSION['user_email'] = $row["email"];
                $_SESSION["user_font"] = $row["font"];
                $_SESSION["user_bg_color"] = $row["theme"];
                $_SESSION["user_paper_color"] = $row["pad_style"];

                // Redirect to the home page
                header('Location: home-page.php');
                exit();
            } else {
                // Passwords do not match
                $errorMessage = "Incorrect password!!!";
            }
        } else {
            // User not found
            $errorMessage = "User not found";
        }
    } else {
        // Query execution error
        die("Error executing the query: " . $conn->error);
    }

    $conn->close();

?>
