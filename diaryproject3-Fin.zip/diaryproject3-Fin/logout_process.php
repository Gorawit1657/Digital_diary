<?php
// Start the session
session_start();

// Clear all session data
session_unset();

// Destroy the session
session_destroy();

// Redirect to welcome.php after logout
header('Location: welcome.php');
exit();
?>
