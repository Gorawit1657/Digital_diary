<?php
// Start the session
session_start();

// Check if the user is logged in by verifying if the 'user_id' session variable exists
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_username = $_SESSION['user_username'];
    $user_font = $_SESSION["user_font"];
    $user_bg_color = $_SESSION["user_bg_color"];
    $user_paper_color = $_SESSION["user_paper_color"];

    if ($user_bg_color == 1) {
        $user_bg_color_code = '#a7d7c5';
        $user_subbg_color_code = '#c1e3d6';
    } elseif ($user_bg_color == 2) {
        $user_bg_color_code = '#3388ff';
        $user_subbg_color_code = '#77ccff';
    } elseif ($user_bg_color == 3) {
        $user_bg_color_code = '#fea95e';
        $user_subbg_color_code = '#f9ddb1';
    }

    // You can now use $user_id in your page
} else {
    // If the 'user_id' session variable doesn't exist, the user is not logged in
    // You can handle this situation by redirecting them to the login page or displaying an error message
    header('Location: login.php');
    exit();
}
?>



<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>new goal</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400%2C700"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400%2C700"/>
  <link rel="stylesheet" href="./styles/new-goal.css"/>
  <script>
       document.addEventListener("DOMContentLoaded", function() {
        var mainbg = document.querySelector('.new-goal-Q3S');
        var subbg1 = document.querySelector('.rectangle-7-Y9e');
        var subbg2 = document.querySelector('.rectangle-8-rw2');
        var user_bg_color_code = "<?php echo $user_bg_color_code; ?>";
        var user_subbg_color_code = "<?php echo $user_subbg_color_code; ?>";

        mainbg.style.backgroundColor = user_bg_color_code;
        subbg1.style.backgroundColor = user_subbg_color_code;
        subbg2.style.backgroundColor = user_subbg_color_code;
    });
  </script>
</head>


<body>
<div class="new-goal-Q3S">
  <div class="rectangle-7-Y9e">
  </div>
  <div class="rectangle-8-rw2">
  </div>
  <div class="rectangle-26-oLU">
  </div>
  <a href="setting.php" style="text-decoration: none;">
  <div class="user01-L5W">
    <img class="vector-rZe" src="./assets/vector-koi.png"/>
    <p class="user01-zvk"><?php echo $user_username; ?></p>
    <img class="vector-10-X9z" src="./assets/vector-10-EEC.png"/>
  </div>
  </a>
  <form action="new_goal_process.php" method="POST">
  <div class="group-2-eEc">
    <div class="auto-group-kjhz-89n">
      <div class="title-eP2">
        <div class="rectangle-2-nVE">
        </div>
        <p class="tittle-BGU">Title</p>
        <input type="text" name="goal_title" id="goal_title" placeholder="Title" class="rectangle-2-nVE" required/>
      </div>
      <p class="new-goal-gU8">New Goal</p>
    </div>
    <div class="date-PNY">
      <p class="date-Wxx">Date</p>
      <input type="date" name="goal_date" id="goal_date" placeholder="Date" class="auto-group-cngj-EPA" required/>
    </div>
    <div class="date-Tmi">
      <div class="auto-group-wnkt-CUQ">
        <p class="time-YYG">Time</p>
        <input type="time" name="goal_start_time" id="goal_start_time" placeholder="Start Time" class="auto-group-s9l7-sKe" required/>
      </div>
      <p class="to-j6x">to</p>
      <input type="time" name="goal_end_time" id="goal_end_time" placeholder="End Time" class="auto-group-uu4p-rSU" required/>
    </div>
    <div class="date-UCx">
      <p class="description-1Ct">Description</p>
      <input type="text" name="goal_description" id="goal_description" placeholder="Description" class="auto-group-gjkv-vKr" required/>
    </div>
    <div class="auto-group-j1ss-AEC">
      <div class="create-button-6tY">
        <a href="goal-planner.php" style="text-decoration: none;">
        <div class="create-acc-r72">Cancel</div>
        </a>
      </div>
      <div class="save-LH6">
        <button class="create-acc-Vfn">Save</button>
      </div>
    </div>
  </div>
  </form>
  <a href="goal-planner.php" style="text-decoration: none;">
  <img class="vector-MCC" src="./assets/vector-LNc.png"/>
  </a>
</div>
</body>