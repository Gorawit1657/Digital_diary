<?php
// goal_details.php

$diary_id = $_GET['diary_id'];
$currentDate = date("Y-m-d");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $add_comment_tb = $_POST["add_comment_tb"];

    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $q = "INSERT INTO `comment`(`comment_id`, `diary_id`, `comment_date`, `comment_content`) VALUES (NULL,$diary_id,'$currentDate','$add_comment_tb')";
    if (!$conn->query($q)) {
        echo "INSERT FAILED. ERROR" . $conn->error;
    }

    // Close the database connection
    $conn->close();

    header('Location: comment.php?diary_id=' . $diary_id);

}
?>
