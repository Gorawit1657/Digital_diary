<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
    }

    // Retrieve data from the form
    $diary_title = isset($_POST["diary_title"]) ? $_POST["diary_title"] : "";
    $diary_date = isset($_POST["diary_date"]) ? $_POST["diary_date"] : "";
    $diary_content = isset($_POST["diary_content"]) ? $_POST["diary_content"] : "";

 // Create a database connection (modify these values as needed)
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $q = "INSERT INTO `diary` (`diary_id`, `user_id`, `diary_title`, `diary_content`, `diary_date`) VALUES (NULL, '$user_id', '$diary_title', '$diary_content', '$diary_date');";

    if (!$conn->query($q)) {
        echo "INSERT FAILED. ERROR" . $conn->error;
    }
    else{
        header('Location: entry.php');
        exit();
    }

    // Close the connection
    $conn->close();
}
?>
