<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
    }

    // Retrieve data from the form
    $goal_title = isset($_POST["goal_title"]) ? $_POST["goal_title"] : "";
    $goal_date = isset($_POST["goal_date"]) ? $_POST["goal_date"] : "";
    $goal_description = isset($_POST["goal_description"]) ? $_POST["goal_description"] : "";
    $goal_start_time = isset($_POST["goal_start_time"]) ? $_POST["goal_start_time"] : "";
    $goal_end_time = isset($_POST["goal_end_time"]) ? $_POST["goal_end_time"] : "";

    // Create a database connection (modify these values as needed)
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $q = "INSERT INTO `goal` (`goal_id`, `user_id`, `goal_title`, `goal_description`, `goal_date`, `goal_start_time`, `goal_end_time`,`goal_complete`) VALUES (NULL, '$user_id', '$goal_title', '$goal_description', '$goal_date', '$goal_start_time', '$goal_end_time',0);";

    if (!$conn->query($q)) {
        echo "INSERT FAILED. ERROR" . $conn->error;
    }
    else{
        header('Location: on-going.php');
        exit();
    }

    // Close the connection
    $conn->close();
}
?>
