<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>setting page 8</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Courier+New%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arial%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Times+New+Roman%3A400"/>
  <link rel="stylesheet" href="./styles/setting-page-8.css"/>
</head>
<body>
<div class="setting-page-8-2PT">
  <div class="rectangle-7-n7j">
  </div>
  <div class="rectangle-8-ui9">
  </div>
  <div class="group-3-G2u">
    <p class="pad-style-zDo">PAD STYLE</p>
    <div class="auto-group-hvrf-Uuf">

      <button style="background: #f6fbf9; width: 35rem; height: 35rem; " onclick="redirectToBackgroundUpdate(1)">

      </button>
      
      <button style="background: #333333; width: 35rem; height: 35rem; " onclick="redirectToBackgroundUpdate(2)">

      </button>

      <button style="background: #f9e4bc; width: 35rem; height: 35rem; " onclick="redirectToBackgroundUpdate(3)">

      </button>


    </div>

    <p class="now-lets-customize-the-in-side-of-your-journal-N7B">Now Let’s customize the in side of your journal.</p>
    <div class="auto-group-7cvf-4Eu">
      <p class="arial-PY5">White</p>
      <p class="times-new-roman-vY1">Black</p>
      <p class="courier-new-fEh">Yellow</p>
    </div>

  </div>
    <script>
    function redirectToBackgroundUpdate(id) {
      window.location.href = 'pad_update_process.php?id=' + id;
    }
  </script>
</div>
</body>