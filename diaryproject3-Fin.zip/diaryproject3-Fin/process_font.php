<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $selectedFont = $_POST['selectedFont'];
  echo $selectedFont; // This will be the response to your AJAX request
  echo ('Yoooo');
}
?>