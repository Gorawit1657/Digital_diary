<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>register</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400%2C700"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400%2C700"/>
  <link rel="stylesheet" href="./styles/register.css"/>
</head>
<body>
<div class="register-whole-bg">
  <div class="rectangle-light-bg1">
  </div>
  <div class="rectangle-light-bg2">
  </div>
  <form action="register_process.php" method="POST">
  <div class="group-signup-bg">
    <p class="create-an-account-FVa">Create An Account</p>
    <div class="type-95A">
        <div class="auto-group-rkw9-5zQ">
            <input type="text" name="register_user_first_name" id="register_user_first_name" placeholder="FIRST NAME" class="first-name-tb" required/>
            <input type="text" name="register_user_last_name" id="register_user_last_name" placeholder="LAST NAME" class="last-name-tb" required/>
        </div>
        <input type="text" name="register_user_username" id="register_user_username" placeholder="USERNAME" class="username-tb" required/>
        <input type="text" name="register_user_email" id="register_user_email" placeholder="EMAIL" class="email-tb" />
        <input type="text" name="register_user_password" id="register_user_password" placeholder="PASSWORD" class="password-tb" required/>
    </div>
    <div class="create-button-group">
        <button class="create-acc-button">Create Account</button>
      <p class="already-have-an-account-sign-in-Ey6">
        <span class="already-have-an-account-0">Already Have An Account? </span>
        <span class="already-have-an-account-1">
            <a href="login.php">Sign In</a>
        </span>

      </p>
    </div>
  </div>
  </form>
</div>
</body>
</html>
