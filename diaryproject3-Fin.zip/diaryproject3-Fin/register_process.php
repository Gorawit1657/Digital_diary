<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $first_name = $_POST["register_user_first_name"];
    $last_name = $_POST["register_user_last_name"];
    $user_username = $_POST["register_user_username"];
    $user_email = $_POST["register_user_email"];
    $user_password = $_POST["register_user_password"];

    // Hash the password
    $hashed_password = password_hash($user_password, PASSWORD_DEFAULT);

    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the username already exists
    $checkUsernameQuery = "SELECT * FROM log_in WHERE username = '$user_username'";
    $checkResult = $conn->query($checkUsernameQuery);

    if ($checkResult->num_rows > 0) {
        // Username already exists, display an error message
        header('Location: register.php');
        $conn->close();
        exit();
    }

    // Insert the new user
    $q = "INSERT INTO `log_in` (`user_id`, `username`, `password`, `email`) VALUES (NULL, '$user_username', '$hashed_password', '$user_email');";
    if (!$conn->query($q)) {
        echo "INSERT FAILED. ERROR" . $conn->error;
    }

    // Retrieve the user's id
    $sql = "SELECT user_id FROM log_in WHERE log_in.username = '$user_username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Match found, retrieve the user's id
        $row = $result->fetch_assoc();
        $id = $row["user_id"];

        session_start();

        // Store the user_id in a session variable
        $_SESSION['user_id'] = $id;
        $_SESSION['user_username'] = $user_username;
        $_SESSION['user_email'] = $user_email;
        $_SESSION['user_first_name'] = $first_name;
        $_SESSION['user_last_name'] = $last_name;
        $_SESSION['user_font'] = 1;
        $_SESSION['user_bg_color'] = 1;
        $_SESSION['user_paper_color'] = 1;

        // Insert user details into the 'user' table
        $sq = "INSERT INTO `user` (`user_id`, `f_name`, `l_name`, `font`, `theme`, `pad_style`) VALUES ($id, '$first_name', '$last_name', 1, 1, 1);";
        if (!$conn->query($sq)) {
            echo "INSERT FAILED. ERROR" . $conn->error;
        }

        // Redirect to the home page
        header('Location: intro_page_1.php');
        exit();
    } else {
        // No match, return id = 0
        echo "No match, id = 0";
    }

    $conn->close();
}

?>
