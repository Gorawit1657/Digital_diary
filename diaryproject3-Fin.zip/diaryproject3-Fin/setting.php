<?php
// Start the session
session_start();

// Check if the user is logged in by verifying if the 'user_id' session variable exists
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_username = $_SESSION['user_username'];
    $user_password = $_SESSION['user_password'];
    $user_font = $_SESSION["user_font"];
    $user_bg_color = $_SESSION["user_bg_color"];
    $user_paper_color = $_SESSION["user_paper_color"];
    $user_email = $_SESSION["user_email"];

    if ($user_bg_color == 1) {
        $user_bg_color_code = '#a7d7c5';
        $user_subbg_color_code = '#c1e3d6';
    } elseif ($user_bg_color == 2) {
        $user_bg_color_code = '#3388ff';
        $user_subbg_color_code = '#77ccff';
    } elseif ($user_bg_color == 3) {
        $user_bg_color_code = '#fea95e';
        $user_subbg_color_code = '#f9ddb1';
    }

    // You can now use $user_id in your page
} else {
    // If the 'user_id' session variable doesn't exist, the user is not logged in
    // You can handle this situation by redirecting them to the login page or displaying an error message
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>entry</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arial%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400%2C700"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400%2C700"/>
  <link rel="stylesheet" href="./styles/entry-2qN.css"/>

     <script>
       document.addEventListener("DOMContentLoaded", function() {
        var mainbg = document.querySelector('.entry-PWY');
        var subbg1 = document.querySelector('.rectangle-7-Xck');
        var subbg2 = document.querySelector('.rectangle-8-1np');
        var user_bg_color_code = "<?php echo $user_bg_color_code; ?>";
        var user_subbg_color_code = "<?php echo $user_subbg_color_code; ?>";

        mainbg.style.backgroundColor = user_bg_color_code;
        subbg1.style.backgroundColor = user_subbg_color_code;
        subbg2.style.backgroundColor = user_subbg_color_code;
    });
  </script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    var fontSelector = document.getElementById('font-selector');
    var radios = document.querySelectorAll('input[type="radio"][name="background"]');
    var padRadios = document.querySelectorAll('input[type="radio"][name="pad_style"]');
    var background_selectedColor = "#a7d7c5"; // Default background color
    var pad_selectedColor = "#f6fbf9"; // Default pad style color

    for (var i = 0; i < radios.length; i++) {
        radios[i].addEventListener('change', function() {
            background_selectedColor = this.value;
            updateBackgroundColors();
        });
    }

    for (var i = 0; i < padRadios.length; i++) {
        padRadios[i].addEventListener('change', function() {
            pad_selectedColor = this.value;
            updateBackgroundColors();
        });
    }

    function updateBackgroundColors() {
        var settingPage = document.querySelector('.entry-PWY');
        var rectangle7 = document.querySelector('.rectangle-7-Xck');
        var rectangle8 = document.querySelector('.rectangle-8-1np');
        var padbgPage = document.querySelector('.example-4Xi');

        settingPage.style.backgroundColor = background_selectedColor;

        if (background_selectedColor === '#a7d7c5') {
            rectangle7.style.backgroundColor = '#c1e3d6';
            rectangle8.style.backgroundColor = '#c1e3d6';
        } else if (background_selectedColor === '#3388ff') {
            rectangle7.style.backgroundColor = '#77ccff';
            rectangle8.style.backgroundColor = '#77ccff';
        } else if (background_selectedColor === '#fea95e') {
            rectangle7.style.backgroundColor = '#f9ddb1';
            rectangle8.style.backgroundColor = '#f9ddb1';
        }

        padbgPage.style.backgroundColor = pad_selectedColor;
    }

    fontSelector.addEventListener('change', function() {
      var selectedFont = this.value;
      var exampleText = document.querySelector('.example-4Xi .your-entry-here-n6L');
      var titleText = document.querySelector('.example-4Xi .entry-title-wtL');
      var dateText = document.querySelector('.example-4Xi .auto-group-bgjm-BMS .tue-10-24-2023-eVv');
      var fontText = document.querySelector('.group-3-RCc .auto-group-xjph-y7e .entry-font-rKr .auto-group-nct5-JSk .font_combobox');

      titleText.style.fontFamily = selectedFont;
      dateText.style.fontFamily = selectedFont;
      exampleText.style.fontFamily = selectedFont;
      fontText.style.fontFamily = selectedFont;
      var xhr = new XMLHttpRequest();
      xhr.open('POST', 'process_font.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
          console.log(xhr.responseText); // You can handle the response here
        }
      };
      xhr.send('selectedFont=' + encodeURIComponent(selectedFont));
    });
  });
  </script>
</head>


<body>
<div class="entry-PWY">
  <div class="rectangle-7-Xck">
  </div>
  <div class="rectangle-8-1np">
  </div>
  <div class="rectangle-26-wRa">
  </div>
  <div class="user01-51z">
    <img class="vector-nBJ" src="./assets/vector-yqi.png"/>
    <p class="user01-JfS"><?php echo $user_username; ?></p>
    <img class="vector-10-Rk4" src="./assets/vector-10-fL4.png"/>
  </div>
  <a href="home-page.php" style="text-decoration: none;">
  <img class="vector-ASk" src="./assets/vector-WDn.png"/>
  </a>
  <div class="group-2-u9S">
    <div class="type-NYp">
      <form  action="update_info_process.php" method="POST">
      <div class="auto-group-zfa3-5TE">
        <div class="auto-group-wcvh-Nx8">

          <input type="text" name="new_username" id="new_username" placeholder="New Username"class="first-n-H3W" value="<?php echo isset($_SESSION['user_username']) ? $_SESSION['user_username'] : ''; ?>" required/>
          <p class="account-info-9tL">Update Account Info</p>
        </div>

        <input type="text" name="new_password" id="new_password" placeholder="New Password"class="last-n-FRa" required/>
      </div>
      <div class="email-4tp">

        <input type="text" name="new_email" id="new_email" placeholder="New Email"class="auto-group-keb5-Hma" value="<?php echo isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''; ?>"required/>
      </div>
      
      <button class="password-H9J">Update</button>
      </form>
    </div>
    <div class="setting-uAg">
      <div class="auto-group-4ko1-2m6">
        <div class="horizontal-line-ZW8">
          <img class="vector-1-GvL" src="./assets/vector-1-Get.png"/>
          <img class="vector-2-Qme" src="./assets/vector-2.png"/>
          <img class="vector-3-9z8" src="./assets/vector-3.png"/>
        </div>
        <p class="entry-font-PtU">ENTRY FONT</p>
        <a href="font_selector.php" style="text-decoration: none;">
        <div class="arial-u68">Change</div>
        </a>

        <div class="journal-back-ground-QYg">
          <p class="journal-background-vX2">JOURNAL BACKGROUND</p>
          <a href="background_selector.php" style="text-decoration: none;">
          <div class="background_btn"> Change </div>
          </a>

        </div>
      </div>
      <div class="pad-style-mnY">
        <p class="pad-style-hgC">PAD STYLE</p>
            <a href="pad_selector.php" style="text-decoration: none;">
            <div class ="pad_btn">Change</div>
            </a>
      </div>
    </div>
    <div class="auto-group-aust-jMz">
      <div class="create-button-Gcp">
        <a href="logout_process.php" class="create-acc-Qj2"  style="text-decoration: none;">Log Out</a>

      </div>
      <div class="save-GmE">
         <a href="account_delete.php" style="text-decoration: none;">
        <div class="create-acc-2VW" >Delete Account</div>
        </a>
      </div>
    </div>
  </div>
</div>
</body>