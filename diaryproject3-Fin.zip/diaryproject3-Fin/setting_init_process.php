<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $first_name = $_POST["register_user_first_name"];
    $last_name = $_POST["register_user_last_name"];
    $user_username = $_POST["register_user_username"];
    $user_email = $_POST["register_user_email"];
    $user_password = $_POST["register_user_password"];



    session_start();

        // Store the user_id in a session variable
    $_SESSION['user_id'] = $id;
    $_SESSION['user_first_name'] = $first_name;
    $_SESSION['user_last_name'] = $last_name;



        // Redirect to the home page
    header('Location: intro_page_3.php');
    exit();


    } else {
        // No match, return id = 0
        echo "No match, id = 0";
    }

}
?>
