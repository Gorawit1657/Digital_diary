<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "digital_diary";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to check if the username and password match in the database
$sql = "SELECT `diary_title`,`diary_date`,`diary_content` FROM `diary` WHERE user_id = 1 ORDER BY `diary_date` ASC";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Loop through all rows
    while ($row = $result->fetch_assoc()) {
        $diary_title = $row["diary_title"];
        $diary_date = $row["diary_date"];
        $user_diary_content = $row["diary_content"];

        // Process or display the data as needed
        echo "Title: $diary_title, Description: $diary_date, Date: $user_diary_content, Start Time: $user_goal_start_time, End Time: $user_goal_end_time <br>";
    }
} else {
    // No match, return id = 0
    echo "No match, id = 0";
}

$conn->close();
?>
