<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $new_username = $_POST["new_username"];
    $new_password = $_POST["new_password"];
    $new_email = $_POST["new_email"];

    // Create a database connection (modify these values as needed)
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "digital_diary";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Assuming user_id is stored in the session
    $user_id = $_SESSION['user_id'];

    // Hash the new password
    $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update the user information in the database
    $sql = "UPDATE log_in SET username='$new_username', password='$hashed_new_password', email='$new_email' WHERE user_id = $user_id";

    if ($conn->query($sql) === TRUE) {
        // Update session variables with the new information
        $_SESSION['user_username'] = $new_username;
        $_SESSION['user_password'] = $hashed_new_password; // Store the hashed password in the session
        $_SESSION['user_email'] = $new_email;

        // Redirect to home-page.php
        header('Location: home-page.php');
        exit();
    } else {
        echo "Error updating user information: " . $conn->error;
    }

    $conn->close();
}
?>
