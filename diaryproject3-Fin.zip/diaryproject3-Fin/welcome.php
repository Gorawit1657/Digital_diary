<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>welcome</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=B612%3A400%2C700"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400%2C500%2C700"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Barlow+Condensed%3A500"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400"/>
  <link rel="stylesheet" href="./styles/welcome.css"/>
</head>
<body>
<div class="welcome-HLt">
  <div class="rectangle-7-Rhz">
  </div>
  <div class="rectangle-8-Lpx">
  </div>
  <div class="group-2-spt">
    <p class="welcome-to-digital-diary-ktg">
      <span class="welcome-to-digital-diary-ktg-sub-0">Welcome to</span>
      <span class="welcome-to-digital-diary-ktg-sub-1">
       
      <br/>
      
      </span>
      <span class="welcome-to-digital-diary-ktg-sub-2">Digital Diary</span>
    </p>
    <p class="online-diary-you-can-trust-V7W">
    
    <br/>
    Online diary you can trust!
    <br/>
    
    </p>
    <div class="auto-group-htrj-Bm2">
      <a href="login.php" style="text-decoration: none;">
      <div class="login-btn-Ldv">Sign in</div>
      </a>
      <a href="register.php" style="text-decoration: none;">
      <div class="login-btn-YEC">Sign up</div>
      </a>
    </div>
  </div>
</div>
</body>