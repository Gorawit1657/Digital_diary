<?php
// Start the session
session_start();

// Check if the user is logged in by verifying if the 'user_id' session variable exists
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_username = $_SESSION['user_username'];
    $user_font = $_SESSION["user_font"];
    $user_bg_color = $_SESSION["user_bg_color"];
    $user_paper_color = $_SESSION["user_paper_color"];

    if ($user_bg_color == 1) {
        $user_bg_color_code = '#a7d7c5';
        $user_subbg_color_code = '#c1e3d6';
    } elseif ($user_bg_color == 2) {
        $user_bg_color_code = '#3388ff';
        $user_subbg_color_code = '#77ccff';
    } elseif ($user_bg_color == 3) {
        $user_bg_color_code = '#fea95e';
        $user_subbg_color_code = '#f9ddb1';
    }

    if ($user_paper_color == 1) {
        $user_pad_code = '#f6fbf9';
    } elseif ($user_paper_color == 2) {
        $user_pad_code = '#333333';
    } elseif ($user_paper_color == 3) {
        $user_pad_code = '#f9e4bc';
    }

    if ($user_font == 1) {
        $user_font_code = 'Arial';
    } elseif ($user_font == 2) {
        $user_font_code = 'Times New Roman';
    } elseif ($user_font == 3) {
        $user_font_code = 'Courier New';
    }

    // You can now use $user_id in your page
} else {
    // If the 'user_id' session variable doesn't exist, the user is not logged in
    // You can handle this situation by redirecting them to the login page or displaying an error message
    header('Location: login.php');
    exit();
}
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="icon" href="/favicon.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <title>writing pad</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla%3A400"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A400"/>
  <link rel="stylesheet" href="./styles/writing-pad.css"/>

    <script>
       document.addEventListener("DOMContentLoaded", function() {
        var mainbg = document.querySelector('.writing-pad-U8x');
        var subbg1 = document.querySelector('.rectangle-7-qdi');
        var subbg2 = document.querySelector('.rectangle-8-ViG ');
        var pad_location = document.querySelector('.writing-pad-bmJ');
        var font_title = document.querySelector('.entry-title-gbi');
        var font_description = document.querySelector('.your-entry-here-bAx');
        var font_date = document.querySelector('.tue-10-24-2023-hrG');



        var user_bg_color_code = "<?php echo $user_bg_color_code; ?>";
        var user_subbg_color_code = "<?php echo $user_subbg_color_code; ?>";
        var user_pad_code = "<?php echo $user_pad_code; ?>";
        var user_font_code = "<?php echo $user_font_code; ?>";
        

        mainbg.style.backgroundColor = user_bg_color_code;
        subbg1.style.backgroundColor = user_subbg_color_code;
        subbg2.style.backgroundColor = user_subbg_color_code;
        pad_location.style.backgroundColor = user_pad_code;
        font_title.style.fontFamily = user_font_code;
        font_description.style.fontFamily = user_font_code;
        font_date.style.fontFamily = user_font_code;

    });
  </script>
</head>

<body>
<div class="writing-pad-U8x">
  <div class="rectangle-7-qdi">
  </div>
  <div class="rectangle-8-ViG">
  </div>
  <form action="new_diary_process.php" method="POST">
  <div class="writing-pad-bmJ">
    <div class="auto-group-iuwv-UTi">
      <input type="date" name="diary_date" id="diary_date" placeholder="Date" class="tue-10-24-2023-hrG" required/>
    </div>
    <textarea name="diary_content" id="diary_content" placeholder="Your entry here" class="writing-pad-U8x writing-pad-bmJ your-entry-here-bAx" required></textarea>

    <img class="vector-1-ddS" src="./assets/vector-1.png"/>
    <img class="vector-2-MZS" src="./assets/vector-2-tuv.png"/>
     <input type="text" name="diary_title" id="diary_title" placeholder="Diary Title" class="entry-title-gbi" required/>
    <button class="save-btton-n8x">SAVE</button>
  </div>

  <div class="rectangle-26-59z">
  </div>

  <a href="setting.php" style="text-decoration: none;">
  <div class="user01-nq6">
    <img class="vector-JHe" src="./assets/vector-FP6.png"/>
    <p class="user01-qoN"><?php echo $user_username; ?></p>
    <img class="vector-10-Aak" src="./assets/vector-10-7ha.png"/>
  </div>
  </a>
  <a href="entry.php" style="text-decoration: none;">
  <img class="vector-uHS" src="./assets/vector-LNc.png"/>
  </a>
  </form>
</div>
</body>